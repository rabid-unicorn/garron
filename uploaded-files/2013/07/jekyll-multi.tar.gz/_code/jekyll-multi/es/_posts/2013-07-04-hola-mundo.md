---
layout: es-post
title: Hola Mundo
date: 2013-07-04 18:22:35 -04:00
---
Este es solo un post de prueba, para demostrar como se puede crear un sitio bilingüe usando Jekyll como generador del sitio.





